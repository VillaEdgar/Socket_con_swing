
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import sockets.SocketClient;
import sockets.SocketServer;

public class Cliente extends JFrame {

    JTextField texto;
    JTextField puerto;
    JTextField ip;

    public Cliente() {
        super();
        setSize(500, 500);
        setTitle("Conneccion");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel textito = (JPanel) this.getContentPane();
        textito.setLayout(new BorderLayout());

        texto = new JTextField("0", 30);
        texto.setFont(new Font("Comic Sans", Font.BOLD, 25));
        texto.setHorizontalAlignment(JTextField.CENTER);
        texto.setEditable(false);
        texto.equals("Ingresa la ip en la izquierda y el puerto en la derecha");
        textito.add("North", texto);

        JPanel valores = (JPanel) this.getContentPane();
        valores.setLayout(new BorderLayout());

        puerto = new JTextField("0", 30);
        puerto.setFont(new Font("Comic Sans", Font.BOLD, 25));
        puerto.setHorizontalAlignment(JTextField.RIGHT);
        puerto.setEditable(true);

        ip = new JTextField("0", 30);
        ip.setFont(new Font("Comic Sans", Font.BOLD, 25));
        ip.setHorizontalAlignment(JTextField.LEFT);
        ip.setEditable(true);

        valores.add("Left", ip);
        valores.add("Right", puerto);

        String ip = this.ip.getText();
        int puerto = Integer.parseInt(this.puerto.getText());

        JButton conectar = new JButton("conectar");
        coneccion(ip, puerto);
    }

    private void coneccion(String ip, int puerto) {
        SocketClient socket = new SocketClient(ip, puerto);
    }
    
    private void coneccion(String ip, String puerto) {
        SocketServer socket = new SocketServer();
    }

    public static void main(String[] args) {
        Cliente ventana = new Cliente();
        ventana.setVisible(true);
    }
}
